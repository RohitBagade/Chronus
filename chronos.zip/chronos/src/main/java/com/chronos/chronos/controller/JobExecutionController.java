package com.chronos.chronos.controller;

import com.chronos.chronos.dto.JobExecutionResponse;
import com.chronos.chronos.entity.Job;
import com.chronos.chronos.service.JobExecutionService;
import com.chronos.chronos.repository.JobRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/jobs")
@RequiredArgsConstructor
public class JobExecutionController {

    private final JobExecutionService jobExecutionService;
    private final JobRepository jobRepository;

    @GetMapping("/{id}/logs")
    public ResponseEntity<List<JobExecutionResponse>> getJobLogs(@PathVariable Long id) {
        Job job = jobRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Job not found"));

        List<JobExecutionResponse> logs = jobExecutionService.getExecutionsForJob(job);
        return ResponseEntity.ok(logs);
    }
}
