package com.chronos.chronos.service;

import com.chronos.chronos.dto.JobExecutionResponse;
import com.chronos.chronos.entity.Job;
import com.chronos.chronos.entity.JobExecution;
import com.chronos.chronos.repository.JobExecutionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class JobExecutionServiceImpl implements JobExecutionService {

    private final JobExecutionRepository executionRepository;

    @Override
    public void logExecution(Job job, String status, String errorLog) {
        JobExecution execution = JobExecution.builder()
                .job(job)
                .startTime(LocalDateTime.now())
                .endTime(LocalDateTime.now()) // for now, same time; will adjust with real execution
                .status(status)
                .errorLog(errorLog)
                .build();
        executionRepository.save(execution);
    }

    @Override
    public List<JobExecutionResponse> getExecutionsForJob(Job job) {
        return executionRepository.findByJob(job).stream()
                .map(ex -> JobExecutionResponse.builder()
                        .executionId(ex.getExecutionId())
                        .startTime(ex.getStartTime())
                        .endTime(ex.getEndTime())
                        .status(ex.getStatus())
                        .message(ex.getErrorLog() == null ? "Execution successful" : ex.getErrorLog())
                        .build()
                )
                .collect(Collectors.toList());
    }
}
